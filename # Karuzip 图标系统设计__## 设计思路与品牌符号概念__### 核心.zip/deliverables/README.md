# Karuzip — Brand & Icon Assets (Concept A: "Karu K")

Deliverable SVG set for the Karuzip brand. All files are clean, standalone SVG.

## Colors
| Token | Hex | Use |
|---|---|---|
| Brand Blue | `#2B6FD6` | primary / tile |
| Deep | `#225BB0` | accent, slider node, .7z badge |
| Bright | `#4A90E2` | highlight (sparingly) |
| Ink | `#1D2632` | text / line icons / .rar badge |
| Gray | `#8893A3` | secondary, file outlines |
| Surface | `#FAFBFC` | light background |
| Line | `#EEF2F6` | dividers / light surface alt |

## /brand
- `karuzip-app-icon.svg` — App icon (rounded-square tile + white "K" + slider node). 512 grid.
- `karuzip-mark-mono.svg` — Mark only, single color (`currentColor`). For one-color / reverse use.
- `karuzip-mark-on-light.svg` — Blue mark for light surfaces.
- `karuzip-logo-horizontal.svg` — Mark + "Karuzip" wordmark (Karu = Ink, zip = Brand Blue).
- `karuzip-logo-horizontal-mono.svg` — One-color lockup (`currentColor`).

Wordmark font: **Lexend** 700 (fallback Segoe UI). Convert text to outlines if the font is unavailable on the target.

## /icons  (functional, 24×24, stroke 2px, round)
extract · compress · preview · lock(暗号化) · settings · add · extract-to(解凍先) · recent · verify(検査) · search.
Stroke uses `currentColor` — set `color` to recolor.

## /status (24×24, stroke 2px, round, `currentColor`)
state-done · state-error · state-loading (rotate the second path for spin) · icon-folder.

## /files (24×24, full color, fixed)
file-zip · file-7z · file-rar · file-archive. Document body white + gray outline + colored format ribbon — reads on light and dark desktops.

## Family extensibility
The "K" mark is the family constant. Sibling products (KaruPDF, …) keep the K + tile and change only the accent / wordmark suffix.
